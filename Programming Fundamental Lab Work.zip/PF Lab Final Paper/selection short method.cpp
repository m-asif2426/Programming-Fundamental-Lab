#include <iostream>
using namespace std;
int main(){
	int arr[]={8,0,2,4,7,2};
	for(int i=0;i<sizeof(arr)/sizeof(int);i++)
	{
	for(int j=i;j<sizeof(arr)/sizeof(int);j++)
    	{
    	if(arr[j]<arr[i])
	      { 
	     int temp=arr[i];
	    arr[i]=arr[j];
	    arr[j]=temp;
        	}
    	}
	}
	for(int i=0;i<sizeof(arr)/sizeof(int);i++)
	{
	cout<<arr[i]<<endl;
	}
}