#include<iostream>
using namespace std;

int main()
{
    string name[6]={"Amina", "Bilal", "Saba", "Ahmed", "Sana", "Irfan"};
    string subject[6]={"PF", "PF", "Calculus", "OOP", "Calculus", "DSA"};
    int roll_number[6]={35, 48, 49, 59, 35, 52};
    int semester[6]={1, 1, 1, 1, 1, 2};
    for(int i=0; i<6; i++)
        cout<<name[i]<<"\t"<<roll_number[i]<<"\t\t"<<subject[i]<<"\t"<<semester[i]<<endl;

    cout<<"\nStudents of 2nd Semester:\n";
    for(int i=0; i<6; i++)
    if(semester[i]==2)            cout<<name[i]<<"\t"<<roll_number[i]<<"\t\t"<<subject[i]<<"\t"<<semester[i]<<endl;

    cout<<"\nStudents of 1st Semester having PF Subject:\n";
    for(int i=0; i<6; i++)
        if(semester[i]==1 && subject[i]=="PF")
            cout<<name[i]<<"\t"<<roll_number[i]<<"\t\t"<<subject[i]<<"\t"<<semester[i]<<endl;
            
    return 0;}