#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
int calculateScore(const string& answerKey, const string& studentAnswers) {
    int score = 0;
    for (int i = 0; i < answerKey.length(); ++i) {
        if (studentAnswers[i] == answerKey[i]) {
            score += 2;
        }
        else if (studentAnswers[i] != ' ') {
            score -= 1;
        }
    }
    return score;
}
char determineGrade(double percentage) {
    if (percentage >= 90) {
        return 'A';
    }
    else if (percentage >= 80) {
        return 'B';
    }
    else if (percentage >= 70) {
        return 'C';
    }
    else if (percentage >= 60) {
        return 'D';
    }
    else {
        return 'F';
    }
}
int main() {
    const int MAX_STUDENTS = 150;
    const int QUESTIONS = 20;
    const string answerKey = "TFFTFFTTTTFFTFTFTFTT";
    string studentData[MAX_STUDENTS];
    int numStudents = 0;
    cout<<"Enter student data (ID followed by answers, 'q' to quit):" << endl;
    while (numStudents < MAX_STUDENTS) {
        string studentID, studentAnswers;
        getline(cin, studentID);
        if (studentID == "q") {
            break;
        }
        getline(cin, studentAnswers);
        studentData[numStudents] = studentID + " " + studentAnswers;
        numStudents++;
    }
    cout<<setw(15)<<left<<"Student ID"<<setw(25)<<left<<"Test Answers"<<setw(10)<<left<<"Score"<<"Grade"<<endl;
    for (int i = 0; i < numStudents; ++i) {
        string studentID = studentData[i].substr(0, studentData[i].find(' '));
        string studentAnswers=studentData[i].substr(studentData[i].find(' ') + 1);
        int score=calculateScore(answerKey,studentAnswers);
        double percentage=static_cast<double>(score)/(2*QUESTIONS)*100;
        char grade=determineGrade(percentage);
        cout<<setw(15)<<left<<studentID<<setw(25)<<left<<studentAnswers<<setw(10)<<left<<score<<grade<<endl;
    }
    if (numStudents==0) {
        cout<<"No student data entered. Exiting program." << endl;
    }
    return 0;
}