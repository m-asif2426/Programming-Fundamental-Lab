#include <iostream>
using namespace std;
void getInput(double& currentPrice, double& priceOneYearAgo, double& priceTwoYearsAgo) 
{
    cout << "Enter the current price of the item: Rs";
    cin >> currentPrice;
    cout << "Enter the price of the item one year ago: Rs";
    cin >> priceOneYearAgo;
    cout << "Enter the price of the item two years ago: Rs";
    cin >> priceTwoYearsAgo;
}
void calculateInflation(double currentPrice, double priceOneYearAgo, double priceTwoYearsAgo, double& inflationYear1, double& inflationYear2, bool& increasing) 
{
    inflationYear1 = (priceOneYearAgo - currentPrice) / priceOneYearAgo;
    inflationYear2 = (priceTwoYearsAgo - priceOneYearAgo) / priceTwoYearsAgo;
    increasing = (inflationYear2 > inflationYear1);
}
void outputResults(double inflationYear1, double inflationYear2, bool increasing) 
{
    cout << "Inflation rate for the first year: " << (inflationYear1 * 100) << "%" << endl;
    cout << "Inflation rate for the second year: " << (inflationYear2 * 100) << "%" << endl;
    if (increasing) {
        cout << "Inflation is increasing." << endl;
    } else {
        cout << "Inflation is decreasing." << endl;
    }
}
int main() {
    double currentPrice, priceOneYearAgo, priceTwoYearsAgo;
    double inflationYear1, inflationYear2;
    bool increasing;
    getInput(currentPrice, priceOneYearAgo, priceTwoYearsAgo);
    calculateInflation(currentPrice, priceOneYearAgo, priceTwoYearsAgo, inflationYear1, inflationYear2, increasing);
    
    outputResults(inflationYear1, inflationYear2, increasing);
    return 0;
}