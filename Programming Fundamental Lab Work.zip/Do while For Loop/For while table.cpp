#include <iostream>
using namespace std;
int main(){
	int n;
	cout<<"enter the number "<<endl;
	cin>>n;
	for(int c=1;c<=10;c++)
	{
		cout<<n<<" * "<<c<<" = "<<n*c<<endl;
	}
}
