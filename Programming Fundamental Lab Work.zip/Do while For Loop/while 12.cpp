#include <iostream>
using namespace std;
int main(){
	int i=10;
	while(i>=0)
	{
		cout<<i<<endl;
		i--;
	}
}