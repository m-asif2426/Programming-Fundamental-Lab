#include <iostream>
using namespace std;
int main(){
	int n;
	cout<<"Enter number of table "<<endl;
	cin>>n;
	int c=1;
	while(c<=10)
	{
		cout<<n<<" * "<<c<<" = "<<n*c<<endl;
		c++;
	}
}
	
	