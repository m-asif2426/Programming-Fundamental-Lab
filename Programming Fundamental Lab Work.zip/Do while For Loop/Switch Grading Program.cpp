#include <iostream>
using namespace std;
int main(){
   int score,grade;
   cout<<"Enter the subject score :";
   cin>>score;
   switch(score/10)
   {
       case 0:
       case 1:
             case 2:
            case 3:
                case 4:
                    grade='G';
               cout<<" grade = G ";
                   break;
                       case 5:
                           cout<<" grade = F";
                           break;
       case 6:
            cout<<" grade = E ";
            break;
       case 7:
           cout<<"grade = D ";
           break;
       case 8:
           cout<<"grade = C";
           break;
       case 9:
           cout<<"grade  = B ";
           break ;
       case 10:
           cout<<" grade = A ";
           break;
       default:
           cout<<" you can not obtain grade"<<endl;
   }

}