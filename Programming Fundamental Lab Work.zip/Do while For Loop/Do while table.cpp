#include <iostream>
using namespace std;
int main(){
	int n;
	cout<<"enter the number "<<endl;
	cin>>n;
	 int c=1;
	do
	{
		cout<<n<<" * "<<c<<" = "<<c*n<<endl;
		c++;
	}
	while (c<=10);
}