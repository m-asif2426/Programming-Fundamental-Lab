#include <iostream>
using namespace std;
int main()
{ 
  int num,div,sum=0;
 cout<<"Enter a number"<<endl;
 cin>>num;
 for(int i=1;i<num;i++)
    {
     div=num%i;
     if(div==0)
       {
          sum=sum+i;
    	}   
    }
  if(sum==num)
     {
     cout<<"perfect"<<endl;
     }
  else 
    
     cout<<"not perfect"<<endl;
    
}