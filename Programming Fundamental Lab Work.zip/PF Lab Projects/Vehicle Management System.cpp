#include <iostream>

using namespace std;

const int MAX_VEHICLES = 10000;

string makes[MAX_VEHICLES] ;
string models[MAX_VEHICLES] ;
string color[MAX_VEHICLES];
string date[MAX_VEHICLES];
int years[MAX_VEHICLES] ;
double prices[MAX_VEHICLES] ;
double rentalRates[MAX_VEHICLES];


int i;
void displayDetails(int index) {
    cout << index << "\t";
    cout << " Make: " << makes[index] << ", Model: " << models[index] << ", Year: " << years[index]  << ", Date " << date[index]<< ", Color:" << color[index];
    cout << ", Price: Rs" << prices[index] << ", Rental Rate: Rs" << rentalRates[index] << endl;
}


double calculateRentalCost(int index, int numDays) {
    return numDays * rentalRates[index];
}

void addVehicle(int &vehicleCount) {
    if (vehicleCount < MAX_VEHICLES) {
        cout << "\nEnter Make: ";
        cin >> makes[vehicleCount];
        cout << "\nEnter Model: ";
        cin >> models[vehicleCount];
        cout << "\nEnter Year: ";
        cin >> years[vehicleCount];
         cout << "\nEnter Date: ";
        cin >> date[vehicleCount];
        cout << "\nEnter color: ";
        cin >> color[vehicleCount];
        cout << "\nEnter Price: Rs";
        cin >> prices[vehicleCount];
        
        vehicleCount++;
        cout << "\nVehicle added successfully!\n";
    }
    else
    {
        cout << "\nMaximum number of vehicles reached!\n";
    }
}

void markAsSoldOrDelete(int &vehicleCount)
{
    int vehicleIndex;

    if (vehicleCount >= 0)
    {
        cout << "Enter the index of the vehicle you want to mark as sold or delete (0-" << vehicleCount - 1 << "): ";
        cin >> vehicleIndex;

        if (vehicleIndex >= 0 && vehicleIndex < vehicleCount)
        {
            char choice;
            cout << "Details of the selected vehicle:\n";
            displayDetails(vehicleIndex);
            cout << "Do you want to mark as sold (S) or delete (D)? ";
            cin >> choice;

            if (choice == 'S' || choice == 's')
            {
                if (rentalRates[i])
                {
                    cout << "Vehicle already rented. Cannot be marked as sold.\n";
                }
                else
                {
                    for (int i = vehicleIndex; i < vehicleCount - 1; ++i)
                    {
                        makes[i] = makes[i + 1];
                        models[i] = models[i + 1];
                        years[i] = years[i + 1];
                        prices[i] = prices[i + 1];
                        rentalRates[i] = rentalRates[i + 1];
                    }
                    vehicleCount--;

                    cout << "Vehicle marked as sold successfully!\n";
                }
            }
            else if (choice == 'D' || choice == 'd')
            {
                for (int i = vehicleIndex; i < vehicleCount - 1; ++i)
                {
                    makes[i] = makes[i + 1];
                    models[i] = models[i + 1];
                    years[i] = years[i + 1];
                    prices[i] = prices[i + 1];
                    rentalRates[i] = rentalRates[i + 1];
                }
                vehicleCount--;

                cout << "Vehicle deleted successfully!\n";
            }
            else
            {
                cout << "Invalid choice. Please enter 'S' for sold or 'D' for delete.\n";
            }
        }
        else
        {
            cout << "Invalid vehicle index. Please enter a valid index.\n";
        }
    }
    else
    {
        cout << "No vehicles available. Add vehicles first!\n";
    }
}

void rentalManagement(int vehicleCount)
{
    cout << "Rental Vehicle Management\n";
    int vehicleIndex;
    int numDays;
    int index;
    if (vehicleCount > 0)
    {
    
        cout << "Enter the index of the vehicle you want to rent (0-" << vehicleCount - 1 << "): ";
        cin >> vehicleIndex;
        if (vehicleIndex >= 0 && vehicleIndex < vehicleCount)
        {
        	cout << "\nEnter Rental Rate per day: Rs";
            cin >> rentalRates[vehicleCount];
            index = rentalRates[vehicleCount];
            cout << "Enter the number of days for rental: ";
            cin >> numDays;
            int mul =  index * numDays;
            cout << "Rental cost for " << numDays << " days: Rs" << mul << endl;
        }
        else
        {
            cout << "Invalid vehicle index. Please enter a valid index.\n";
        }
    }
    else
    {
        cout << "No vehicles available for rental. Add vehicles first!\n";
    }
}

int main()
{

    int choice;
    int vehicleCount = 0;

    do
    {
        cout << "                                                                                         " << endl;
        cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<WELCOME>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
        cout << "                                                                                         " << endl;
        cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Vehicle Management System>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
        cout << "\nVehicle Management System Menu:\n";
        cout << "\nPress 1. For Add Vehicle\n";
        cout << "\nPress 2. Mark Vehicle as Sold or Delete\n";
        cout << "\nPress 3. Rental Vehicle Management\n";
        cout << "\nPress 4. Display All Vehicles\n";
        cout << "\nPress 5. Exit\n";
        cout << "\nEnter your choice (1-5): ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            addVehicle(vehicleCount);
            break;

        case 2:
            markAsSoldOrDelete(vehicleCount);
            break;

        case 3:
            rentalManagement(vehicleCount);
            break;

        case 4:
            if (vehicleCount > 0)
            {
                cout << "\nAll Vehicles:\n";
                for (int i = 0; i < vehicleCount; ++i)
                {
                    displayDetails(i);
                }
            }
            else
            {
                cout << "No vehicles to display. Add vehicles first!\n";
            }
            break;

        case 5:
            cout << "Exiting Vehicle Management System. Goodbye!\n";
            break;

        default:
            cout << "Invalid choice. Please enter a number between 1 and 5.\n";
        }
    } while (choice != 5);

    return 0;
}