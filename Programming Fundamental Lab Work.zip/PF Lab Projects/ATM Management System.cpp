#include <iostream>

using namespace std;

const int MAX_ACCOUNTS = 100;  

void create_account(string name[], char type[], int number[], double long balance[], int& i,double pincode[])
{
	
    cout << "Enter account holder name: "<<endl;
	cin.ignore();
    getline(cin,name[i]);
    cout<<"Enter account number :";
    cin>>number[i];
    cout<<"Enter pin code :";
    cin>>pincode[i];
    cout << "Enter account type: ";
    cin >> type[i];
    cout << "Enter starting money: $";
    cin >> balance[i];  
    cout << "Account created successfully!" << endl;
    i++;
}

void display_account(string name[], char type[], int number[], double long balance[], int num,double pincode[])
{
	bool check=false;
	for (int j=0;j<MAX_ACCOUNTS;j++)
	{
		if (num==number[j])
		{
			check=true;
			cout<<"Enter pincode :";
			int code;
			cin>>code;
			if (code==pincode[j])
			{
			cout << "Account holder name: " << name[j] << endl;
    		cout << "Account type: " << type[j] << endl;
    		cout << "Total money: $" << balance[j] << endl;
    		cout<<"Account pincode: "<<pincode[j]<<endl;
    		}
    		else
    			cout<<"Incorrect pincode!"<<endl;
		}
	}
	if (!check)
	cout<<"Account not found !"<<endl;
}
void deposit_money(double long balance[],int number[],int num,double pincode[])
{
	bool check=false;
	for (int j=0;j<MAX_ACCOUNTS;j++)
	{
		if (num==number[j])
		{
			check=true;
			cout<<"Enter pincode :";
			int code;
			cin>>code;
			if (code==pincode[j])
			{
			cout<<"Enter the amount you have deposited : $";
			int money;
			cin>>money;
			balance[j]=balance[j]+money;
			cout<<money <<"$ are deposited into your account !"<<endl;
			cout<<"Your new balance is $"<<balance[j]<<endl;
			break;
			}
			else
				cout<<"Incorrect code!"<<endl;
		}
	}
	if (!check)
	cout<<"Account not found !"<<endl;
	
}
void withdraw_amount(double long balance[],int number[],int num,double pincode[])
{
	bool check=false;
	for (int j=0;j<MAX_ACCOUNTS;j++)
	{
		if (num==number[j])
		{
			check=true;
			cout<<"Enter pincode :";
			int code;
			cin>>code;
			if (code==pincode[j])
			{
			cout<<"Enter the amount that you can withdraw : $";
			int money;
			cin>>money;
			balance[j]=balance[j]-money;
			cout<<money<<"$ withdraw from your account : "<<endl;
			cout<<"Your new balance is $"<<balance[j]<<endl;
			break;
			}
			else
				cout<<"Incorrect pincode!"<<endl;
		}
	}
	if (!check)
	cout<<"Account not found !"<<endl;
}
void delete_account(string name[], char type[], int number[], double long balance[], int& i,int num,double pincode[])
{
	bool check=false;
	for (int j=0;j<MAX_ACCOUNTS;j++)
	{
		if (num==number[j])
		{
			check=true;
			cout<<"Enter pincode :";
			int code;
			cin>>code;
			if (code==pincode[j])
			{
				name[j]=name[j+1];
				number[j]=number[j+1];
				type[j]=type[j+1];
				balance[j]=balance[j+1];
				pincode[j]=pincode[j+1];
				cout<<"Account deleted successfully !"<<endl;
				i--;
			}
			else
				cout<<"Incorrect pincode!"<<endl;
			
		}
			
	}
	if (!check)
	cout<<"Account not found !"<<endl;
}
void transfer_amount(int number[],double long balance[],double pincode[])
{
	cout<<"Enter account number from you transfer : ";
	int num;
	cin>>num;
	bool check=false;
	bool checks=false;
	for (int j=0;j<MAX_ACCOUNTS;j++)
	{
		if (num==number[j])
		{
			check=true;
			cout<<"Enter pincode :";
			int code;
			cin>>code;
			if (code==pincode[j])
			{
			cout<<"Enter account number where you transfer : ";
			int n;
			cin>>n;
			for (int k=0;k<MAX_ACCOUNTS;k++)
			{
				if (n==number[k])
				{
					checks=true;
					cout<<"Enter pincode :";
					int code;
					cin>>code;
					if (code==pincode[k])
					{
					cout<<"Enter amount that you can transfer : $";
					int amount;
					cin>>amount;
					balance[j]=balance[j]-amount;
					balance[k]=balance[k]+amount;
					cout<<"New balance of account no "<<number[j]<<" = $"<<balance[j]<<endl;
					cout<<"New balance of account no "<<number[k]<<" = $"<<balance[k]<<endl;
					break;
					}
					else
						cout<<"Incorrect code!"<<endl;
				}
			}
			if (!checks)
				cout<<"Account not found !"<<endl;
		}
		else 
			cout<<"Incorrect pincode!"<<endl;	
		
		
		break;
	}
	}
	if (!check)
		cout<<"Account not found !"<<endl;
	
}
void pay_utilitybills(double bill_amount,double long balance[],int number[],int num,double pincode[])
{
	bool check=false;
	for (int j=0;j<MAX_ACCOUNTS;j++)
	{
		if (num==number[j])
		{
			check=true;
			cout<<"Enter pincode :";
			int code;
			cin>>code;
			if (code==pincode[j])
			{
				
			if (balance[j]>=bill_amount)
			{
				balance[j]=balance[j]-bill_amount;
				cout<<"Utility bill has been successfully paid!"<<endl;
				cout<<"your new balance is $"<<balance[j]<<endl;
			}
			else
				cout<<"Insufficents funds!"<<endl;
		}
			else
				cout<<"Incorrect pincode!"<<endl;
	}
	if (!check)
	cout<<"Account not found !"<<endl;
}}
void review()
{
	cout<<"Are you satisfy from bank policies (yes/no)? ";
	string result;
	cin>>result;
	cout<<"Are you satisfy from bank staff (yes/no)? ";
	cin>>result;
	cout<<"Are you satify from bank environment (yes/no)? ";
	cin>>result;
	
}

int main()
{
    string name[MAX_ACCOUNTS];
    char type[MAX_ACCOUNTS];
    int number[MAX_ACCOUNTS];
    double long balance[MAX_ACCOUNTS];
    double pincode[MAX_ACCOUNTS];
    int i = 2;  
    int choice;
    name[0]="GHULAM MUSTAFA";
    number[0]=12;
    balance[0]=500;
    pincode[0]=1234;
    type[0]='c';
    name[1]="ahmad ali";
    number[1]=15;
    balance[1]=500;
    pincode[1]=5678;
    type[1]='c';

	do{
	cout<<"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<WELCOME>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"<<endl;
	cout<<"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<BANK MANAGEMENT SYSTEM>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"<<endl;
    cout << "\tpress 1 for create account" << endl;
    cout << "\tpress 2 for display information" << endl;
    cout<<"\tpress 3 for deposit money "<<endl;
    cout<<"\tpress 4 for withdraw amount"<<endl;
    cout<<"\tpress 5 for delete account"<<endl;
    cout<<"\tpress 6 for transfer amount"<<endl;
    cout<<"\tpress 7 for par utility bills "<<endl;
    cout<<"\tpress 8 for review the bank"<<endl;
    cout<<"\tpress 9 to exit the bank"<<endl;
    cout << "Enter choice: ";
    cin >> choice;

    if (choice == 1)
        create_account(name, type, number, balance, i,pincode);
    else if (choice == 2)
    {
        cout << "Enter account number: ";
        int num;
        cin >> num;
        display_account(name, type, number, balance, num,pincode);
    }
    else if (choice == 3)
    {
    	cout<<"Enter account number : ";
    	int num;
    	cin>>num;
    	deposit_money(balance,number,num,pincode);
	}
	else if (choice==4)
	{
		cout<<"Enter account number : ";
    	int num;
    	cin>>num;
    	withdraw_amount(balance,number,num,pincode);
	}
	else if (choice == 5)
	{
		cout<<"Enter account number : ";
		int num;
		cin>>num;
		delete_account(name, type, number, balance, i,num,pincode);
	}
	else if (choice==6)
	{
		transfer_amount(number,balance,pincode);
	}
	else if (choice==7)
	{
	
		cout<<"Enter utility bill amount : ";
		double bill_amount;
		cin>>bill_amount;
		cout<<"Enter account number : ";
		int num;
		cin>>num;
		pay_utilitybills(bill_amount,balance,number,num,pincode);
	}
	else if (choice==8)
	{
		review();
	}
	else 
		cout<<"Invalid choice !"<<endl;
}

while (choice !=9);
    return 0;
}
