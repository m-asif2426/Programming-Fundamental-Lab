#include <iostream>
using namespace std;
int main(){
	int width, length, area, peri;
	cout<<"find the area and perimeter of a rectangle"<<endl;
	cout<<"input the length of rectangle :";
	cin>>length ;	
	cout<<"input the width of rectangle : ";
	cin>>width ;
	area = length*width;
	peri = 2*(length+width);
	cout <<"the area of rectangle : "<<area << endl;
	cout <<"the peri of rectangle : " <<peri <<endl;
}