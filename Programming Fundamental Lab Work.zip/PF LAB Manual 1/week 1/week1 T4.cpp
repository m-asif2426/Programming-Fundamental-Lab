#include <iostream>
using namespace std;
int main(){
	cout<<"****\n ***\n  **\n   *";
	return 0;
	}