#include <iostream>
using namespace std;
int main(){
	int num1,num2,choice;
	cout<<"Enter the Two Number :"<<endl;
	cin>>num1>>num2;
	cout<<" 1 Press for applying SUM "<<endl;
	cout<<" 2 Press for applying MULTIPLY "<<endl;
	cout<<" 3 Press for applying SUBTRACT "<<endl;
	cout<<" 4 Press for applying DIVID    "<<endl;
	cin>>choice;
	if(choice == 1)
	{
		int sum = num1+num2;
		cout<<num1<<" + "<<num2<<" = "<<sum<<endl;
	}
	else if(choice == 2)
	{
		int mul = num1*num2;
		cout<<num1<<" * "<<num2<<" = "<<mul<<endl;
	}
	else if(choice == 3)
	{
		int sub= num1 - num2;
		cout<<num1<<" - "<<num2<<" = "<<sub<<endl;
	}
	else if(choice == 4)
	{
	    float div = num1 / num2;
	    cout<<num1<<" / "<<num2<<" = "<<div<<endl;
	}
}