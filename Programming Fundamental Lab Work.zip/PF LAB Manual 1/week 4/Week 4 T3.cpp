#include <iostream>
using namespace std;
int main(){
	int num1,num2,num3;
    cout<<"Enter the Three Number :";
    cin>>num1>>num2>>num3;
    if( num1 <= num2 && num1<=num3)
    {
        cout<<"The Smallest number is :"<<num1<< endl;
    }
    else if(num2<=num1&&num2<=num3)
    {
        cout<<"The Smallest number is :"<<num2<<endl;
    }
    else if(num3<=num1&&num3<=num2)
    {
        cout<<"The Smallest number is :"<<num3<<endl;
    }
}