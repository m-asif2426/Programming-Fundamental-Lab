#include <iostream>
using namespace std;
int main(){
	int marks;
    cout<<" Total Marks is 100 "<<endl;
	cout<<"Enter Obtain The Marks :";
	cin>>marks;
	switch (marks % 10)
    {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
            cout << "Admission successfully";
            break;
        case 8:
            cout << "Admission successfully";
            break;
        case 9:
            cout << "Admission successfully";
            break;
        case 10:
            cout << "Admission successfully";
            break;
        default:
            cout << "ineligible for admission";
    }
}