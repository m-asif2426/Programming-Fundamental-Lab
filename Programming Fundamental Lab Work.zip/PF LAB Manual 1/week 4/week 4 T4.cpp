#include <iostream>
using namespace std;
int main(){
	int num;
	cout<<"Enter the Number :";
	cin>>num;
	 num = num % 2;
	if(num<=0)
	{
		cout<<"The number is Even"<<endl;
	}
	else
	{
		cout<<"The number is odd"<<endl;
	}
}