#include <iostream>
using namespace std;
int main() {
    int intermarks;
    cout<<"Enter the inter marks :";
    cin>>intermarks;
    if(intermarks >=70 )
       {
         cout << "you are allow :" <<intermarks<<endl;
            int entrymarks;
            cout<<"Enter the entry marks :";
            cin>>entrymarks;
                   if(entrymarks>=50)
                {
                   cout<<"you are allow :"<<entrymarks<<endl;
                      int interviewmarks ;
                      cout<<"Enter the interview marks :";
                      cin>>interviewmarks;
                         if(interviewmarks >= 50)
                         {
                           cout<<"you are allow :"<<endl;
                         }
                         int average = (intermarks+entrymarks+interviewmarks)/3;
                                 if(average>50)
                                 {
                                     cout<<"your admission is successfully "<<average<<endl;
                                 }
                }
       }
       else
           {
                cout<<"apply next year"<<endl;
            }
}