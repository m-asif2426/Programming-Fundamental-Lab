#include <iostream>
using namespace std;
int main(){
	int a=10,c;
	cout<<"The product of all odd numbers from 1 to 10 "<<endl;
	c = 1;
	while(c<=a)
	{
		if(c%2==1)
		{
		cout<<c<<endl;
	    }
		c++;
	}
}