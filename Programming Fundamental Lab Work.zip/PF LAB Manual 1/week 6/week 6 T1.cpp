#include <iostream>
using namespace std;
int main(){
	int num,c;
	cout<<"Enter The Number :";
	cin>>num;
	c=1;
	while(c<=num)
	{
		cout<<"Pakistan"<<endl;
		c++;
	}
	
}