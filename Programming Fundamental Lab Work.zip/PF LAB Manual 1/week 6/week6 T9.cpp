#include <iostream>
using namespace std;
int main(){
            int num1,num2,remainder,rev=0;
            cout<<"enter any number"<<endl;
            cin>>num2;
            num1=num2;
    while(num2!=0)
         {
            remainder=num2%10;
             rev=(rev*10)+remainder;
            num2=num2/10;		
         }
            cout<<"reverse number is : "<<rev<<endl;
    if(num1==rev)
     {
	     cout<<"the number is palindrome"<<endl;
       }
   else
          {
         cout<<"the number is not palindrome"<<endl;
          }
}