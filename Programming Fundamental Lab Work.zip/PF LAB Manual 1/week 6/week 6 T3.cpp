#include <iostream>
using namespace std;
int main(){
	int a=5,c;
	cout<<"Display Number of Square :"<<endl;
	c = 1;
	while(c<=a)
	{
		cout<<c<<" = "<<c*c<<endl;
		c++;
	}
}