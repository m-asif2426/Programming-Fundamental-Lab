#include <iostream>
using namespace std;
int main(){
	for(int a=1;a<=5;a++)
	{
		for(int k=5;k>=a ;k--)
		{
			cout<<"*";
		}
		cout<<endl;
	}
}

