#include <iostream>
using namespace std;
int main(){
	int evesum=0,oddsum=0,num=2;
	while(num<=30)
	{if(num%2==0)
	{evesum=evesum+num;
	}
	else
	{oddsum=oddsum+num;
	}
	num++;
	}
	cout<<"sum of even integers  "<<evesum<<endl;
	cout<<"sum of odd integers  "<<oddsum<<endl;
}