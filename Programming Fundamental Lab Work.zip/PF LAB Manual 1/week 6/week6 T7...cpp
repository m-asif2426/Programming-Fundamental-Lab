#include <iostream>
using namespace std;
int main(){
	int num,choice;
	cout<<"Enter value of num "<<endl;
	cin>>num;
	cout<<"choose below two series one at a time"<<endl;
	cout<<"1- 1+2+3+....+n"<<endl;
	cout<<"2- 1*2*3*....*n"<<endl;
	cin>>choice;
	if(choice==1)
	{
	 int sum=0;
      	for(int a=1;a<=num;a++)
	     {
	        sum=sum+a;
        	}
	            cout<<"sum of series  ="<<sum<<endl;
	}
    else if(choice==2)
	    {      
	      long double product=1;
        	for(int k=1;k<=num;k++)
	    {
         	product=product*k;
    	}
	cout<<"product of  series  ="<<product<<endl;
	   }
	else
    	{
	     cout<<"invalid choice"<<endl;
	   }
	
}