#include <iostream>
using namespace std;
int main(){
	int b;
	cout<<"Enter the number :";
	cin>>b;
	for(int a=1;a<=10;a++)
	{
		cout<<a<<"*"<<b<<"="<<(a*b)<<endl;
	}
}