#include <iostream>
using namespace std;
int main(){
	int a=1,c;
	cout<<"back counting from 10 to 1 "<<endl;
	c = 10;
	while(c>=a)
	{
		cout<<c<<endl;
		c--;
	}
}