#include <iostream>
using namespace std;
int main(){
	int a,b,sum,sub,mul,div;
	cout<<"Enter two word :";
	cin>>a>>b;
	sum=a+b;
	cout<<"sum is"<<sum;
	sub=a-b;
	cout<<"sub is"<<sub;
	mul=a*b;
	cout<<"mul is"<<mul;
	div=a/b;
	cout<<"div is"<<div;
}