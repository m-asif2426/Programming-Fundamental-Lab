#include <iostream>
using namespace std;
int main(){
	int a,b;
	cout<<"Enter two word :";
	cin>>a;
	cin>>b;
//	calculating quotient and remainder;
    int quotient=a/b;
    int remainder=a%b;
    
    cout<<"Quotient"<<quotient<<endl;
    cout<<"Remainder"<<remainder<<endl;
}