#include <iostream>
using namespace std;
int main()
{
    cout<<"size of int = "<<sizeof(int)<<" bytes"<<endl;
	cout<<"size of float = "<<sizeof(float)<<" bytes"<<endl;
	cout<<"size of boolean = "<<sizeof(bool)<<" byte"<<endl;
return 0;
}