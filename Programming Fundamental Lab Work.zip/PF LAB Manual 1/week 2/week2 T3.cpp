#include <iostream>
using namespace std;
int main(){
	int a,b;
	cout<<"Enter two word :";
	cin>>a;
	cin>>b;
	//swaping without third variable;
	a=a+b;
	b=a-b;
	a=a-b;
	cout<<"after swaping"<<endl;
	cout<<"a"<<a<<endl;
	cout<<"b"<<b<<endl;	
}