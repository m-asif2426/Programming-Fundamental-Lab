#include <iostream>
using namespace std;
int main(){
    int a,b;
	cout<<"Enter two word :";
	cin>>a;
	cin>>b;
	cout<<"a"<<a<<endl;
	cout<<"b"<<b<<endl;
	int swap;
	swap=a;
	a=b;
	b=swap;
	cout<<"swap a"<<a<<endl;
	cout<<"swap b"<<b<<endl;	
}