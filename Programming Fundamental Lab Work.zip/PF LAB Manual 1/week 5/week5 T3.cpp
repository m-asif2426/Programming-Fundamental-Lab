#include <iostream>
using namespace std;
int main() {
        char gender;
    double bodyWeight, wristMeasurement, waistMeasurement, hipMeasurement, forearmMeasurement;
    double bodyFat, bodyFatPercentage;
    
    cout << "Enter gender (M/F): ";
    cin >> gender;
    cout << "Enter body weight (in pounds): ";
    cin >> bodyWeight;
    cout << "Enter wrist measurement (at fullest point, in inches): ";
    cin >> wristMeasurement;
    cout << "Enter waist measurement (at navel, in inches): ";
    cin >> waistMeasurement;
    cout << "Enter hip measurement (at fullest point, in inches): ";
    cin >> hipMeasurement;
    cout << "Enter forearm measurement (at fullest point, in inches): ";
    cin >> forearmMeasurement;
    
    if (gender == 'F' || gender == 'f') {
        double A1 = (bodyWeight * 0.732) + 8.987;
        double A2 = wristMeasurement / 3.140;
        double A3 = waistMeasurement * 0.157;
        double A4 = hipMeasurement * 0.249;
        double A5 = forearmMeasurement * 0.434;
        double B = A1 + A2 - A3 - A4 + A5;
        bodyFat = bodyWeight - B;
    } else if (gender == 'M' || gender == 'm') {
        double A1 = (bodyWeight * 1.082) + 94.42;
        double A2 = wristMeasurement * 4.15;
        double B = A1 - A2;
        bodyFat = bodyWeight - B;
    } else {
        cout << "Invalid gender. Please enter M or F.\n";
        return 1; 
    }

        bodyFatPercentage = (bodyFat * 100) / bodyWeight;

   
     cout << "Body fat percentage: " << bodyFatPercentage << "%\n";
}
