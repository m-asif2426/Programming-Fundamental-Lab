#include<iostream>
using namespace std;
int main(){
int num;
cout<<"enter any number"<<endl;
cin>>num;
if(num>0)
   {
	cout<<num<<" is a positive"<<endl;
   }
else if(num<0)
    {
	 cout<<num<<" is a negative"<<endl;
   }
else if(num==0)
   {
       cout<<num<<" is a zero"<<endl;
   }
}