#include <iostream>
using namespace std;
int main() {
    int n1, n2;
    char operation;
        cout << "Enter the first number: ";
    cin >> n1;
    cout << "Enter the second number: ";
    cin >> n2;
    cout << "Enter the operation (+, -, *, /): ";
    cin >> operation;
    switch (operation) {
        case '+':
            cout << n1 << " + " << n1 << " = " << n1 + n2 << "\n";
            break;
        case '-':
            cout << n1 << " - " << n2 << " = " << n1 - n2 << "\n";
            break;
        case '*':
            cout << n1 << " * " << n2 << " = " << n1 * n2 << "\n";
            break;
        case '/':
            if (n2 != 0) {
               cout << n1 << " / " << n2 << " = " << static_cast<double>(n1) / n2 << "\n";
            } else {
               cout << "Error: Division by zero is not allowed.\n";
            }
            break;
        default:
            cout << "Invalid operation. Please enter +, -, *, or /.\n";
    }
}
