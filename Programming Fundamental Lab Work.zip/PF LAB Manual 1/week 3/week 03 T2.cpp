#include <iostream>
using namespace std;
int main(){
	int num,sum=0,a;
	cout<<"enter any five digit number"<<endl;
	cin>>num;
	if(num>=10000 && num<=99999)
	{
		while(num!=0)
	  {
		   a=num%10;
		   sum=sum+a;
		   num=num/10;}
		cout<<"the sum of five digits is  "<<sum<<endl;
	  }
	else
	{
	cout<<"sorry! the number you entered is not a five digit number"<<endl;
	}
}
