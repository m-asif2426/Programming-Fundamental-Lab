#include <iostream>
using namespace std;
int main (){
  	int a =10, b = 12, c = 0;
  	int value=a++ + ++a;
  	cout<<"1 The value of  = a++ + ++a is :"<<value<<endl;
  	value =b++ + b-- + a++ + ++a;
  	cout<<"2 The value of = b++ + b-- + a++ + ++a is :"<<value<<endl;
  	value =(c++ * b-- - ++a) / --c;
  	cout<<"3 The value of =(c++ * b-- - ++a) / --c is :"<<value<<endl;
  	value =(c++ % ++b) + --a + a--;
  	cout<<"4 The value of (c++ % ++b) + --a + a-- is :"<<value<<endl; 	
}