 #include <iostream>
using namespace std;
int main(){
	double principal=1000;
	double annualinterest=0.05;
	cout<<"year\tamount on deposit"<<endl;
	for(int year=1;year<=10;year++)
	{
	double amunt=principal+(1+annualinterest)*year;
	cout<<year<<"\t$"<<amunt<<endl;
	}
}
	