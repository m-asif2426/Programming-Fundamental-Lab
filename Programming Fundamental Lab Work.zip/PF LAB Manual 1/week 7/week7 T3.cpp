#include <iostream>
using namespace std;
int main() {
    int accountNum;
    double initialBalance, totalCharges, totalCredits, creditLimit;

    while (true)
	 {
       cout << "Enter account number (-1 to end): ";
       cin >> accountNum;

        if (accountNum == -1)
		 {
            break;
        }

        cout << "Enter initial balance: ";
        cin >> initialBalance;

        cout << "Enter total charges: ";
        cin >> totalCharges;

        cout << "Enter total credits: ";
        cin >> totalCredits;

       cout << "Enter credit limit: ";
        cin >> creditLimit;
        double newBalance = initialBalance + totalCharges - totalCredits;
          if (newBalance > creditLimit) 
		{
            cout << "Account: " << accountNum << "\nBalance: " << newBalance << "\nCredit limit exceeded.\n\n";
        } else
		 {
            cout << "Account: " << accountNum << "\nBalance: " << newBalance << "\nCredit limit not exceeded.\n\n";
        }
    }
}