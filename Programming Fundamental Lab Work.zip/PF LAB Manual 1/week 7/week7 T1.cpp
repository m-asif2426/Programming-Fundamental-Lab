#include <iostream>
using namespace std;
int main(){
	int evsum=0,oddsum=0,num=2;
	while(num<=20)
	{if(num%2==0)
	{evsum=evsum+num;
	}
	else
	{oddsum=oddsum+num;
	}
	num++;
	}
	cout<<"sum of even integers : "<<evsum<<endl;
	cout<<"sum of odd integers  : "<<oddsum<<endl;
}