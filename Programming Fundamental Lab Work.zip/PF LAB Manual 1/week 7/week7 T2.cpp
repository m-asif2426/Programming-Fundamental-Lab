#include <iostream>
using namespace std;
int main ()
{
	int num,n1;
	cout<<"Enter four digit number  "<<endl;
	cin>>num;
	n1=num;
	int p,q=0,divisor=1000,i=0;
	while (n1!=0)
	{
		p=n1%10;
		i=i+1;
		n1=n1/10;
	}
	if (i==4)
	{
		while(i!=0)
		{
			q=num/divisor;
		    cout<<q<<"   ";
		    num=num%divisor;
		    divisor=divisor/10;
		    
	    }
	}
	else
		cout<<"Sorry! The number you entered is NOT a 4 digit number"<<endl;
}