#include <iostream>
using namespace std;
int main() {
    const int scoreRanges = 8;
    int scoreCount[scoreRanges] = {0};
    int testScores[] = {76, 89, 150, 135, 200, 76, 12, 100, 150, 28, 178, 189, 167, 200, 175, 150, 87, 99, 129, 149, 176, 200, 87, 35, 157, 189};
    int numberOfStudents = sizeof(testScores) / sizeof(testScores[0]);
    for (int i = 0; i < numberOfStudents; ++i) {
        int score = testScores[i];

        if (score >= 0 && score <= 24) {
            scoreCount[0]++;
        } else if (score >= 25 && score <= 49) {
            scoreCount[1]++;
        } else if (score >= 50 && score <= 74) {
            scoreCount[2]++;
        } else if (score >= 75 && score <= 99) {
            scoreCount[3]++;
        } else if (score >= 100 && score <= 124) {
            scoreCount[4]++;
        } else if (score >= 125 && score <= 149) {
            scoreCount[5]++;
        } else if (score >= 150 && score <= 174) {
            scoreCount[6]++;
        } else if (score >= 175 && score <= 200) {
            scoreCount[7]++;
        }
    }
    cout << "Score Ranges and Number of Students:" << endl;
    for (int i = 0; i < scoreRanges; ++i) {
        cout << i * 25 << " - " << (i + 1) * 25 - 1 << ": " << scoreCount[i] << " students" << endl;
    }

    return 0;
}
