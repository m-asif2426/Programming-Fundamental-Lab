#include <iostream>
using namespace std;
int main(){
	int arr[4]={2,3,2,4};
	int numt=0;
	int arraysize = sizeof(arr)/sizeof(arr[0]);
	for(int i=0;i<4;i++)
	{
		cout<<arr[i]<<" ";
		numt = numt+arr[i];
		
	}
	cout<<endl;
	cout<<"The size of array is :"<<arraysize<<endl;
	cout<<"Total number of item in it :"<<numt<<endl;
}