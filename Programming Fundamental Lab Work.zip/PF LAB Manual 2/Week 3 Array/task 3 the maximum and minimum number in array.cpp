#include <iostream>
using namespace std;
int main(){
	int array[]={6,7,8,4};
	int max,min;
	for(int i=0;i<4;i++)
	{
		cout<<array[i]<<" ";
		if(array[i]>max)
		{
			 max = array[i];
		}
		else
		   if(array[i]<min)
		   {
		   	 min = array[i];
		   }
	}
	cout<<endl;
	cout<<"The minimum number is :"<<min<<endl;
	cout<<"The maximum number is  :"<<max<<endl;	
} 