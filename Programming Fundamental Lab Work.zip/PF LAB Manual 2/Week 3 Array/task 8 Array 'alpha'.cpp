#include <iostream>
using namespace std;
int main() {
    const int size = 50;
    double alpha[size];
    for (int i = 0; i < size; ++i) {
        if (i < size / 2) {
            alpha[i] = static_cast<double>(i * i);
        } else {
            alpha[i] = static_cast<double>(3 * i);
        }
    }
    cout << "Array 'alpha':" << endl;
    for (int i = 0; i < size; ++i) {
       cout << alpha[i] << " ";
        if ((i + 1) % 10 == 0) {
            cout << endl;
        }
    }
    return 0;
}
