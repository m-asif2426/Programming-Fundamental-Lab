#include <iostream>
using namespace std;
int main() {
    const int arraySize = 5;
    int myArray[arraySize];
    cout << "Enter " << arraySize << " integer values:\n";
    for (int i = 0; i < arraySize; ++i) {
        cout << "Enter value for element " << i << ": ";
        cin >> myArray[i];
    }
    cout << "Entered values in the array are:\n";
    for (int i = 0; i < arraySize; ++i) {
        cout << "Element " << i << ": " << myArray[i] << "\n";
    }
    return 0;
}
