#include <iostream>
using namespace std;
int main() {
    const int maxSize = 100; 
    char inputString[maxSize];
    cout << "Enter a string: ";
    cin.getline(inputString, maxSize);
    for (int i = 0; inputString[i] != '\0'; ++i) {
        if (inputString[i] >= 'a' && inputString[i] <= 'z') {
            inputString[i] = static_cast<char>(inputString[i] - ('a' - 'A'));
        }
    }
    cout << "Uppercase String: " << inputString << endl;
    return 0;
}
