#include <iostream>
using namespace std;
int main() {
    int n;
    cout << "Enter the number of elements in the array: ";
   cin >> n;
    int array[n + 1];
   cout << "Enter " << n << " elements, separated by spaces:" << endl;
    for (int i = 0; i < n; ++i) {
    cin >> array[i];
    }
    int newValue;
   cout << "Enter the new value to insert: ";
   cin >> newValue;
    int position;
    cout << "Enter the position to insert the new value (0-based index): ";
    cin >> position;
    for (int i = n; i > position; --i) {
        array[i] = array[i - 1];
    }
    array[position] = newValue;
  cout << "Updated array after insertion:" << endl;
    for (int i = 0; i < n + 1; ++i) {
        cout << array[i] << " ";
    }
    cout <<endl;
    return 0; 
}
