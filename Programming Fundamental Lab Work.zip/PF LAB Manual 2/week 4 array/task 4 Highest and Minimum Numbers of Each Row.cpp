#include <iostream>
using namespace std;
int main() {
    const int rows = 5;
    const int columns = 10;
    int dataArray[rows][columns];
    for (int i = 0; i < rows; ++i) {
        cout << "Enter data for Row " << i + 1 << " (10 integers separated by spaces): ";
        for (int j = 0; j < columns; ++j) {
            cin >> dataArray[i][j];
        }
    }
    cout << "\nHighest and Minimum Numbers of Each Row:\n";
    for (int i = 0; i < rows; ++i) {
        int highest = dataArray[i][0];
        int minimum = dataArray[i][0];

        for (int j = 1; j < columns; ++j) {
            if (dataArray[i][j] > highest) {
                highest = dataArray[i][j];
            }
            if (dataArray[i][j] < minimum) {
                minimum = dataArray[i][j];
            }
        }
        cout << "Row " << i + 1 << ": Highest = " << highest << ", Minimum = " << minimum << endl;
    }

    int overallHighest = dataArray[0][0];
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < columns; ++j) {
            if (dataArray[i][j] > overallHighest) {
                overallHighest = dataArray[i][j];
            }
        }
    }
    cout << "\nOverall Highest Number in the 2D Array: " << overallHighest << endl;

    int totalSum = 0;
    cout << "\nSum of Each Row and Total Sum:\n";
    for (int i = 0; i < rows; ++i) {
        int rowSum = 0;
        for (int j = 0; j < columns; ++j) {
            rowSum += dataArray[i][j];
        }
        totalSum += rowSum;

        cout << "Row " << i + 1 << ": Sum = " << rowSum << endl;
    }
    cout << "Total Sum of the 2D Array: " << totalSum << endl;

    return 0;
}
