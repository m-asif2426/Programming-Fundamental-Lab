#include <iostream>
using namespace std;
const int months = 12; 
void getData(int temperatures[][2]) {
    for (int i = 0; i < months; ++i) {
        cout << "Enter highest temperature for month " << i + 1 << ": ";
        cin >> temperatures[i][0];

        cout << "Enter lowest temperature for month " << i + 1 << ": ";
        cin >> temperatures[i][1];
    }
}
double averageHigh(int temperatures[][2]) {
    int totalHigh = 0;
    for (int i = 0; i < months; ++i) {
        totalHigh += temperatures[i][0];
    }
    return static_cast<double>(totalHigh) / months;
}

double averageLow(int temperatures[][2]) {
    int totalLow = 0;
    for (int i = 0; i < months; ++i) {
        totalLow += temperatures[i][1];
    }
    return static_cast<double>(totalLow) / months;
}

int indexHighTemp(int temperatures[][2]) {
    int indexHigh = 0;
    for (int i = 1; i < months; ++i) {
        if (temperatures[i][0] > temperatures[indexHigh][0]) {
            indexHigh = i;
        }
    }
    return indexHigh;
}

int indexLowTemp(int temperatures[][2]) {
    int indexLow = 0;
    for (int i = 1; i < months; ++i) {
        if (temperatures[i][1] < temperatures[indexLow][1]) {
            indexLow = i;
        }
    }
    return indexLow;
}

int main() {
    int temperatureData[months][2]; 
    getData(temperatureData);
    cout << "\nAverage High Temperature for the Year: " << averageHigh(temperatureData) << "°C\n";
    cout << "Average Low Temperature for the Year: " << averageLow(temperatureData) << "°C\n";

    int highestIndex = indexHighTemp(temperatureData);
    int lowestIndex = indexLowTemp(temperatureData);

    cout << "Highest Temperature for the Year: " << temperatureData[highestIndex][0] << "°C (Month " << highestIndex + 1 << ")\n";
    cout << "Lowest Temperature for the Year: " << temperatureData[lowestIndex][1] << "°C (Month " << lowestIndex + 1 << ")\n";

    return 0;
}
