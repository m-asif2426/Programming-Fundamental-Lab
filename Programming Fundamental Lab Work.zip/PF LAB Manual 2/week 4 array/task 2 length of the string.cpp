#include <iostream>

using namespace std;

int main() {
    const int maxSize = 100; 
    char inputString[maxSize];
    char copiedString[maxSize];
    int length = 0;
    cout << "Enter a string: ";
    cin.get(inputString, maxSize);
    strcpy(copiedString, inputString);
    length = strlen(inputString);
    cout << "Original String: " << inputString << endl;
    cout << "Copied String: " << copiedString << endl;
    cout << "Length of the String: " << length << endl;

    return 0;
}
