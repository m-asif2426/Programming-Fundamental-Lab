#include <iostream>
using namespace std;
const int numStudents = 5; 
const int numTests = 3;    
void readData(string names[], int scores[][numTests]) {
    for (int i = 0; i < numStudents; ++i) {
        cout << "Enter name for student " << i + 1 << ": ";
        cin >> names[i];

        cout << "Enter test scores for student " << i + 1 << " (3 scores separated by spaces): ";
        for (int j = 0; j < numTests; ++j) {
            cin >> scores[i][j];
        }
    }
}

void calculateAverageAndGrade(int scores[][numTests], char grades[]) {
    for (int i = 0; i < numStudents; ++i) {
        int totalScore = 0;
        for (int j = 0; j < numTests; ++j) {
            totalScore += scores[i][j];
        }

        double average = static_cast<double>(totalScore) / numTests;

        if (average >= 90) {
            grades[i] = 'A';
        } else if (average >= 80) {
            grades[i] = 'B';
        } else if (average >= 70) {
            grades[i] = 'C';
        } else if (average >= 60) {
            grades[i] = 'D';
        } else {
            grades[i] = 'F';
        }
    }
}

void outputResults(string names[], int scores[][numTests], char grades[]) {
    cout << "\nStudent\tTest Scores\tAverage\tGrade\n";
    for (int i = 0; i < numStudents; ++i) {
        cout << names[i] << "\t";
        for (int j = 0; j < numTests; ++j) {
            cout << scores[i][j] << " ";
        }

        int totalScore = 0;
        for (int j = 0; j < numTests; ++j) {
            totalScore += scores[i][j];
        }
        double average = static_cast<double>(totalScore) / numTests;

        cout << "\t\t" << average << "\t" << grades[i] << endl;
    }
}

void outputClassAverage(int scores[][numTests]) {
    int totalScore = 0;
    for (int i = 0; i < numStudents; ++i) {
        for (int j = 0; j < numTests; ++j) {
            totalScore += scores[i][j];
        }
    }

    double classAverage = static_cast<double>(totalScore) / (numStudents * numTests);
    cout << "\nClass Average: " << classAverage << endl;
}

int main() {
    string studentNames[numStudents];
    int testScores[numStudents][numTests];
    char grades[numStudents];

    readData(studentNames, testScores);

    calculateAverageAndGrade(testScores, grades);

    outputResults(studentNames, testScores, grades);

    outputClassAverage(testScores);

    return 0;
}
