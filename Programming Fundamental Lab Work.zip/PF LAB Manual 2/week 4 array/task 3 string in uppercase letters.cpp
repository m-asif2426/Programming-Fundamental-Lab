#include <iostream>

using namespace std;

int main() {
    const int maxSize = 100; 
    char inputString[maxSize];
    cout << "Enter a string: ";
    cin.getline(inputString, maxSize);
    for (int i = 0; inputString[i] != '\0'; ++i) {
        if (inputString[i] >= 'a' && inputString[i] <= 'z') {
            inputString[i] = inputString[i] - ('a' - 'A');
        }
    }
    cout << "String in Uppercase: " << inputString << endl;
    return 0;
}
