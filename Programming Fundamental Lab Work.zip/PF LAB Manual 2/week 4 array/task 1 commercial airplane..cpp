#include<iostream>
using namespace std;
const int rows = 13;
const int seatsPerRow = 6;
char airplane[rows][seatsPerRow];
void initializeSeatingPlan() {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < seatsPerRow; ++j) {
            airplane[i][j] = '*';
        }
    }
}
void displaySeatingPlan() {
    cout << "Seating Plan:\n\n";
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < seatsPerRow; ++j) {
            cout << airplane[i][j] << " ";
        }
        cout << "\n";
    }
    cout << "\n";
}
void assignSeat(char ticketType) {
    int startRow, endRow;

    if (ticketType == 'F' || ticketType == 'f') {
        startRow = 1;
        endRow = 2;
    } else if (ticketType == 'B' || ticketType == 'b') {
        startRow = 3;
        endRow = 7;
    } else if (ticketType == 'E' || ticketType == 'e') {
        startRow = 8;
        endRow = 13;
    } else {
        cout << "Invalid ticket type!\n";
        return;
    }

    for (int i = startRow - 1; i < endRow; ++i) {
        for (int j = 0; j < seatsPerRow; ++j) {
            if (airplane[i][j] == '*') {
                airplane[i][j] = 'X'; // 'X' indicates an occupied seat
                cout << "Seat assigned successfully.\n";
                return;
            }
        }
    }

    cout << "Sorry, no available seats in the selected class.\n";
}
int main() {
    char choice;

    initializeSeatingPlan();

    do {
        cout << "Menu:\n";
        cout << "1. Display Seating Plan\n";
        cout << "2. Assign Seat\n";
        cout << "3. Exit\n";
        cout << "Enter your choice (1-3): ";
        cin >> choice;

        switch (choice) {
            case '1':
                displaySeatingPlan();
                break;
            case '2':
                char ticketType;
                cout << "Enter ticket type (F/B/E): ";
                cin >> ticketType;
                assignSeat(ticketType);
                break;
            case '3':
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice. Please enter a valid option.\n";
        }

    } while (choice != '3');

    return 0;
}
