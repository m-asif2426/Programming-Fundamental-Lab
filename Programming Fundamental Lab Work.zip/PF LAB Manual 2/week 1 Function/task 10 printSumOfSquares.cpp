#include <iostream>
using namespace std;
void printSumOfSquares(int n, int currentSum = 0) {
    if (n >= 0) {
      
        cout << currentSum;

        if (n > 0) {
            cout << "+";
        }

        printSumOfSquares(n - 1, currentSum + n * n);
    }
}

int main() {
    int n;

   cout << "Enter the value of n: ";
   cin >> n;

    printSumOfSquares(n);

    return 0;
}
