#include <iostream>
using namespace std;
int main(){
	int arr[]={2,3,4,7,1,0,4,55};
	for(int i=0;i<sizeof(arr)/sizeof(int);i++)
	{
	for(int j=i;j<sizeof(arr)/sizeof(int);j++)
    	{
    	if(arr[j]>arr[i])
	      { 
	     int temp=arr[i];
	    arr[i]=arr[j];
	    arr[j]=temp;
        	}
    	}
	}
	for(int i=0;i<sizeof(arr)/sizeof(int);i++)
	{
	cout<<arr[i]<<endl;
	}
}