#include <iostream>
using namespace std;
void printParameters(int num, float decimal, char character, string text)
 {
    cout << "Number: " << num << endl;
    cout << "Decimal: " << decimal << endl;
    cout << "Character: " << character << endl;
    cout << "Text: " << text << endl;
}

int main() {
    int number = 10;
    float decimalNumber = 3.14;
    char letter = 'A';
    string message = "Hello, world!";
    printParameters(number, decimalNumber, letter, message);
    return 0;
}
