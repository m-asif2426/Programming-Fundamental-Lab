#include <iostream>
#include <cmath>
using namespace std;
double getWindChill() { 
    double speed;
    cout << "Enter the wind speed in miles per hour: ";
    cin >> speed;
    return speed;
}
double calculateWindChill(double speed, double temperature) {
    return 35.74 + 0.6215 * temperature - 35.75 * pow(speed, 0.16) + 0.4275 * temperature * pow(speed, 0.16);
}
int main() {
    double windSpeed = getWindChill();
    double temperature;
    cout << "Enter the temperature in degrees Fahrenheit: ";
    cin >> temperature;
    double windChillFactor = calculateWindChill(windSpeed, temperature);
    cout << "Windchill factor: " << windChillFactor << " degrees Fahrenheit" << endl;
    return 0;
}
