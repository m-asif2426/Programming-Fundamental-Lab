#include <iostream>
using namespace std;
void printHelloWorld() {
    cout<<"Hello World"<< endl;
}

int main() {
    printHelloWorld();
    return 0;
}
