#include <iostream>
using namespace std;
int sum(int a, int b) {
  return a + b;
}
int mult(int a, int b) {
  return a * b;
}
int dive(int a, int b) {
  return a / b;
}
int sub(int a, int b) {
  return a - b;
}
int main() {
  int a, b;
  cout << "Enter 1st numbers: ";
  cin >> a;
  cout<<" Enter the 2nd numbers ";
  cin >> b;
  cout << "Sum: " << sum(a, b)<< endl;
  cout << "Multiplication: "<<mult(a, b) << endl;
  cout << "Division: " <<dive(a, b) << endl;
  cout << "Subtraction: " <<sub(a, b) << endl;
  return 0;
}
