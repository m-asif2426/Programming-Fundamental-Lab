#include <iostream>
using namespace std;
int reverseDigit(int num) {
    int reversedNum = 0;
    while (num != 0) {
        int digit = num % 10;
        reversedNum = reversedNum * 10 + digit;
        num /= 10;
    }
    return reversedNum;
}
int main() {
    int inputValue;
    cout << "Enter an integer: ";
    cin >> inputValue;
    int reversedValue = reverseDigit(inputValue);
    cout << "Reversed digits: " << reversedValue <<endl;
    return 0;
}
