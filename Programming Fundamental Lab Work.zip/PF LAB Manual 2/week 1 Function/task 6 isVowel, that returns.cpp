#include <iostream>
using namespace std;
bool isVowel(char character)
{
    char lowercaseChar = tolower(character);
    return (lowercaseChar == 'a' || lowercaseChar == 'e' || lowercaseChar == 'i' ||
            lowercaseChar == 'o' || lowercaseChar == 'u');
}
int main() {
    char inputChar;
    cout << "Enter a character: ";
    cin >> inputChar;
    if (isVowel(inputChar)) {
        cout << inputChar << " is a vowel." <<endl;
    } else {
        cout << inputChar << " is not a vowel." << endl;
    }
    return 0;
}
